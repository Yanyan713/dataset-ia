# 👋 README

## 👋 Bienvenue

Bienvenue au sein de l'équipe Etalab. Tu trouveras dans cet espace les informations nécessaires à ton arrivée. C'est un document ouvert et collaboratif. N'hésite pas à proposer des améliorations!

### Qu'est-ce-qu'Etalab?

* ℹ Etalab et la DINUM
* 🎯 Nos missions
* ✨ Nos produits
* Nos canaux de communication
* Des présentations sur nos sujets
* Travaillez chez Etalab

### Tu es membre d’Etalab

Cet espace a été conçu pour toi. Depuis GitBook, tu peux utiliser la _**barre de recherche**_ en haut à droite de ton écran pour faciliter ta navigation. Si tu ne trouves pas la ressource que tu cherches, tu peux poser la question dans la _**chaîne \~etalab-privé**_ de notre espace Mattermost. Si tu repères une erreur, tu peux la corriger et contribuer à ce guide.

#### La documentation interne

Toute la documentation d'Etalab n'est pas publique. Si tu as accès au GitBook, tu peux consulter la documentation interne.

En attendant, tu peux voir ce que signifie

## Contribuer à cette documentation

Pour éditer ce guide public tu peux apporter directement des modifications aux fichiers.md sur le dépôt etalab/etalab ou accéder à l'éditeur GitBook ici.

Le contenu de ce dépôt est publié sous licence Ouverte 2.0.