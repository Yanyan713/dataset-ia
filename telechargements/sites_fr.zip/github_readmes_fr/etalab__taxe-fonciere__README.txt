# Taxe foncière

Le code source des taxes foncières est produit par la Direction
Générale des Finances publiques (DGFiP).

Il a été initialement publié par la DGFiP sur
data.gouv.fr. Il est republié ici de façon être pouvoir être lu, manipulé, testé par toute personne le souhaitant.

Pour toute demande d'information complémentaire et toute suggestion,
merci de vous référer aux informations disponibles sur data.gouv.fr.

# Licence

Le code source des taxes foncières est publié sous licence CeCILL 2.1.