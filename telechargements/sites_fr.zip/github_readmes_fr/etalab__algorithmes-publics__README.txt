**Ce dépôt est archivé.**

La plus grande partie de son contenu a été transféré sur le dépôt des guides d'Etalab, auquel vous pouvez vous référer pour faire des commentaires, ouvrir des tickets ou proposer des contributions.

Pour tenir à jour la liste des **codes sources** dont la publication contribue à l'explication d'algorithmes publics, rendez-vous sur cette page.

# Les missions d'Etalab sur les algorithmes publics

La mission Etalab accompagne les administrations dans la mise en oeuvre du principe de transparence des algorithmes. 

Ce dépôt contient: 
- le guide des algorithmes publics à l'usage des administrations, 
- la présentation du programme de travail 2018-2019 et des partenaires mobilisés,
- une liste de ressources utiles (rapports, articles, outils, évènements,...).

[In english]

"With great power comes great responsibility": keeping public sector algorithms accountable", working paper for RightsCon 2019, Tunis 

# Licence

Ce document est produit par Simon Chignard pour la mission Etalab et il est publié sous licence Ouverte 2.0.