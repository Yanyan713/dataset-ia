# Taxe d'habitation 2017

Le code de la taxe d'habitation est produit par la **Direction
Générale des Finances
publiques**.

Cette publication s’inscrit dans la mise en œuvre de la Loi pour une
République
numérique,
qui a ajouté à l’article
L300-2
du Code des Relations entre le Public et l’Administration (CRPA) la
mention de codes sources comme documents administratifs.

Le dossier **code_TH** contient les scripts C tels qu'utilisés par la
DGFiP pour calculer la taxe d'habitation 2017.

Le dossier **documentation** contient 3 fichiers: 
* PRO.TH.2017.calent - données en entree.pdf 
* PRO.TH.2017.calsor - données en sortie.pdf 
* PRO.TH.2017.calano - liste des anomalies

Le dossier **calculette** permet de tester le code sur quelques
exemples et contient:
* Un exécutable
* Des fichiers d'exemples
* Une documentation expliquant comment faire fonctionner la calculette sur les jeux d'exemple.

## Politique de contribution

Github.com est ici utilisé comme une plateforme de diffusion et non de
collaboration, le développement et les évolutions du code restant la
compétence de la DGFiP. Le système de tickets a été désactivé.
Aucune _pull request_ portant sur le code C ne pourra être prise en
compte dans la branche master, le code publié devant être le code en
production. Vous pouvez néanmoins créer des forks pour y modifier le
code. Merci de votre compréhension.

## Droits d'auteur et licence

2017-2018 Direction Générale des Finances Publiques

Ce code est sous licence CeCILL v2.1. Voir le fichier
LICENCE.txt.