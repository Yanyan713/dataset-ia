**Archivé**: ce dépôt est archivé et l'API n'est plus en place.

Pour consulter les dépôts développés par le pôle logiciels libres d'Etalab, rendez-vous sur SourceHut.

# But du dépôt

Le but de ce dépôt est de:

- collecter des métadonnées concernant les dépôts publiés par les comptes d'organisation d'organismes publics;
- donner de la visibilité à l'ensemble de ces comptes.

Ne sont pour l'instant traités que les comptes présents sur GitHub et
les forges GitLab.

Pour ajouter le compte d'organisation de votre organisme, vous pouvez proposer de modifier le fichier pertinent dans le dépôt de la DINSIC relatif à la Politique de Contribution Open Source de l'État.

## Déploiement et hébergement

Les données sont mises à jour régulièrement grâce à CircleCI.

## Données

Les données sont publiées aux formats CSV et JSON dans le dossier data. Chaque dossier contient un fichier `all.{csv,json}` qui contient l'ensemble des répertoires ou des organisations. Ces fichiers sont à privilégier lorsque vous souhaitez faire une analyse globale.

## Description des données

Les données sont décrites à l'aide de fichiers Table Schema dans le dossier schemas

### Métadonnées d'un répertoire Git

#### Modèle de données

- Clé primaire: `repository_url`, `organization_name`

|Nom|Type|Description|Exemple|Propriétés|
|-|-|-|-|-|
|name|chaîne de caractères|Le nom du répertoire|nom-repertoire|Valeur obligatoire|
|organization_name|chaîne de caractères|Le nom de l'organisation|etalab|Valeur obligatoire|
|platform|chaîne de caractères|La plateforme de dépôt de code|GitHub|Valeur obligatoire, Valeurs autorisées: GitHub,GitLab|
|repository_url|chaîne de caractères (format `uri`)|L'URL vers le répertoire| obligatoire|
|description|chaîne de caractères|La description du répertoire|Ce répertoire est utile|Valeur optionnelle|
|is_fork|booléen|Indique si le répertoire est un fork|false|Valeur obligatoire|
|is_archived|booléen|Indique si le répertoire est archivé, c'est-à-dire qu'il est en lecture seule|false|Valeur obligatoire|
|creation_date|date et heure|La date de création du répertoire|2018-12-01T20:00:55Z|Valeur obligatoire|
|last_update|date et heure|La date de dernière mise à jour du répertoire|2018-12-01T20:00:55Z|Valeur obligatoire|
|homepage|chaîne de caractères|URL vers la page d'accueil du projet| optionnelle|
|stars_count|nombre entier|Le nombre de fois où le répertoire a été ajouté aux favoris|42|Valeur obligatoire, Valeur minimale: 0|
|forks_count|nombre entier|Le nombre de fois où le répertoire a été forké|13|Valeur obligatoire, Valeur minimale: 0|
|license|chaîne de caractères|La licence du répertoire, telle que détectée par la plateforme|MIT|Valeur optionnelle|
|open_issues_count|nombre entier|Le nombre d'issues actuellement ouvertes|0|Valeur obligatoire, Valeur minimale: 0|
|language|chaîne de caractères|Le langage principal du répertoire, tel que détecté par la plateforme|Python|Valeur optionnelle|
|topics|chaîne de caractères|Les tags du répertoire|utile,france,opendata|Valeur optionnelle|
|software_heritage_exists|booléen|Indique si le répertoire a déjà été archivé sur Software Heritage|false|Valeur obligatoire|
|software_heritage_url|chaîne de caractères (format `uri`)|L'URL vers l'interface web de Software Heritage pour ce répertoire| obligatoire|

### Métadonnées d'une organisation Git

#### Modèle de données

- Clé primaire: `login`

|Nom|Type|Description|Exemple|Propriétés|
|-|-|-|-|-|
|login|chaîne de caractères|Le pseudo de l'organisation|Etalab|Valeur obligatoire|
|description|chaîne de caractères|La description de l'organisation|Observatoire accidentologie plaisance et loisirs nautiques France|Valeur optionnelle|
|nom|chaîne de caractères|Le nom complet de l'organisation|Ministère de l'Intérieur|Valeur optionnelle|
|organization_url|chaîne de caractères (format `uri`)|URL vers l'organisation| obligatoire|
|website|chaîne de caractères (format `uri`)|Site web de l'organisation| optionnelle|
|location|chaîne de caractères|Adresse physique de l'organisation|Paris, France|Valeur optionnelle|
|email|chaîne de caractères (format `email`)|Adresse e-mail de contact de l'organisation|contact@etalab.gouv.fr|Valeur optionnelle|
|is_verified|booléen|Indique si l'organisation a prouvé qu'elle détenait les noms de domaines associés à son organisation|true|Valeur optionnelle|
|repositories_count|nombre entier|Le nombre de répertoires publics de l'organisation|42|Valeur obligatoire, Valeur minimale: 0|
|creation_date|date et heure|La date de création de l'organisation|2013-08-26T16:03:40Z|Valeur optionnelle|
|platform|chaîne de caractères|La plateforme utilisée de l'organisation|GitHub|Valeur obligatoire, Valeurs autorisées: GitHub,GitLab|

# Droits d’auteur et licence

Le code source du répertoire est publié sous la licence MIT. Les données, disponibles dans le répertoire data sont publiées sous la Licence Ouverte 2.0.

© 2018-2021 Direction interministérielle du numérique et du système d’information et de communication de l’État, Antoine Augusti, Bastien Guerry.

© 2018-2021 Les autres contributeurs dans la liste est accessible via l’historique du dépôt.