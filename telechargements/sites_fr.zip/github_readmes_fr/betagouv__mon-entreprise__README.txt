Ce dépôt contient:

- Le code source du site mon-entreprise
- Les règles publicodes pour le calcul des cotisations sociales, des impôts et des droits sociaux.
- Les règles publicodes pour le calcul du montant des exonérations de cotisations liées au covid

## mon-entreprise 

&nbsp;

Site développé en partenariat avec l’Urssaf, qui a pour mission d’accompagner des créateurs d’entreprise dans le développement de leur activité.

Il propose notamment des simulateurs de cotisations sociales très complets, basés sur le language déclaratif publicodes. On peut ainsi calculer le coût d’une embauche, un salaire net après impôt, ses revenus d’auto-entrepreneur ou encore ceux d’un dirigeant de SAS(U) ou d’indépendant

> 🧮 Voir la liste des simulateurs

Les développeurs peuvent intégrer ces simulateurs sur d’autres sites ou réutiliser les règles pour effectuer leurs propres calculs.

> 🧰 Voir les outils à disposition des développeurs

Tous les outils proposés sur mon-entreprise sont propulsés par publicodes, un nouveau langage pour les algorithmes d’intérêt public.

## Contribuer

Si vous souhaitez contribuer à l’un des deux projets, rendez-vous sur CONTRIBUTING.md.

## 🇬🇧 English users

This repository powers mycompanyinfrance.urssaf.fr and mon-entreprise.urssaf.fr

Most of the documentation (including issues and commit message) is written in french, please raise an issue if you are interested and do not speak French.

## 🗜️ Compatibility

The website will run well on modern browsers. Internet Explorer is not supported anymore (it should work but with visual glitches and performance issues).

This compatibility is tested thanks to BrowserStack’s free open source program.